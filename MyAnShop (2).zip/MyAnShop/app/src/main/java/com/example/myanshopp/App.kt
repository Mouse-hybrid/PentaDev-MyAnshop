package com.example.myanshopp

class App {
}