package com.example.myanshopp.data.db.dao

import androidx.room.*
import com.example.myanshopp.data.model.CartItem

@Dao
interface CartDao {

    @Query("SELECT * FROM cart_items WHERE username = :username")
    suspend fun getCart(username: String): List<CartItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CartItem): Long

    @Update
    suspend fun update(item: CartItem)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM cart_items WHERE username = :username")
    suspend fun clear(username: String)
}
