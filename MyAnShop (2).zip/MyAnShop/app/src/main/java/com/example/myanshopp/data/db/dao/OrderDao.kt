package com.example.myanshopp.data.db.dao

import androidx.room.*
import com.example.myanshopp.data.model.Order

@Dao
interface OrderDao {

    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    suspend fun getAllOrders(): List<Order>

    @Query("SELECT * FROM orders WHERE username = :username ORDER BY createdAt DESC")
    suspend fun getByUser(username: String): List<Order>

    @Insert
    suspend fun insert(order: Order): Long

    @Update
    suspend fun update(order: Order)
}
