package com.example.myanshopp.data.db.dao

import androidx.room.*
import com.example.myanshopp.data.model.OrderItem

@Dao
interface OrderItemDao {

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    suspend fun getByOrder(orderId: Long): List<OrderItem>

    @Insert
    suspend fun insert(item: OrderItem): Long

    @Insert
    suspend fun insertAll(items: List<OrderItem>)
}
