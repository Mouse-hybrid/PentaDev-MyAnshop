package com.example.myanshopp.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val totalAmount: Double,
    val createdAt: Long = Date().time,
    val status: OrderStatus = OrderStatus.PENDING,
    val paymentMethod: String = "COD"
)
