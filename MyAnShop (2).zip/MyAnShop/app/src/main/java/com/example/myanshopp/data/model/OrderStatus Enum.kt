package com.example.myanshopp.data.model

enum class OrderStatus {
    PENDING,
    SHIPPING,
    DELIVERED,
    CANCELLED
}
