package com.example.myanshopp.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val username: String,      // Dùng username làm khóa chính
    val displayName: String,
    val password: String,
    val phone: String? = null,
    val address: String? = null,
    val isAdmin: Boolean = false
)
