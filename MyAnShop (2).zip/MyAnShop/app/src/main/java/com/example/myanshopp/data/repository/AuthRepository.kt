package com.example.myanshopp.data.repository

import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.User

class AuthRepository(private val db: AppDatabase) {

    private val userDao = db.userDao()

    // Đăng nhập
    suspend fun login(username: String, password: String): User? {
        val user = userDao.getUser(username)
        return if (user != null && user.password == password) user else null
    }

    // Đăng ký
    suspend fun register(user: User): Boolean {
        val existed = userDao.getUser(user.username)
        if (existed != null) return false // đã tồn tại
        userDao.insertUser(user)
        return true
    }

    // Cập nhật thông tin cá nhân
    suspend fun updateProfile(user: User) {
        userDao.updateUser(user)
    }
}
