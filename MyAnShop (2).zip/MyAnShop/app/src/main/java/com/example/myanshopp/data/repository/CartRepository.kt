package com.example.myanshopp.data.repository

import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.CartItem

class CartRepository(private val db: AppDatabase) {

    private val cartDao = db.cartDao()

    suspend fun getCart(username: String): List<CartItem> =
        cartDao.getCart(username)

    // Thêm vào giỏ
    suspend fun addToCart(username: String, productId: Long, qty: Int = 1) {
        val items = cartDao.getCart(username)

        // Nếu sản phẩm tồn tại trong giỏ -> tăng số lượng
        val existing = items.firstOrNull { it.productId == productId }

        if (existing != null) {
            val updated = existing.copy(quantity = existing.quantity + qty)
            cartDao.update(updated)
        } else {
            cartDao.insert(
                CartItem(
                    username = username,
                    productId = productId,
                    quantity = qty
                )
            )
        }
    }

    // Cập nhật số lượng
    suspend fun updateItem(item: CartItem) {
        cartDao.update(item)
    }

    // Xóa sản phẩm khỏi giỏ
    suspend fun remove(itemId: Long) {
        cartDao.deleteById(itemId)
    }

    // Xóa toàn bộ giỏ của user
    suspend fun clear(username: String) {
        cartDao.clear(username)
    }
}
