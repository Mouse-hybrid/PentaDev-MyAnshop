package com.example.myanshopp.data.repository

import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.Category

class CategoryRepository(private val db: AppDatabase) {

    private val categoryDao = db.categoryDao()

    suspend fun getAll(): List<Category> = categoryDao.getAll()

    suspend fun addCategory(name: String): Long {
        return categoryDao.insert(Category(name = name))
    }

    suspend fun updateCategory(category: Category) {
        categoryDao.update(category)
    }

    suspend fun deleteCategory(category: Category) {
        categoryDao.delete(category)
    }
}
