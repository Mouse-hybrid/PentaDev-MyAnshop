package com.example.myanshopp.data.repository

import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.*

class OrderRepository(private val db: AppDatabase) {

    private val orderDao = db.orderDao()
    private val orderItemDao = db.orderItemDao()
    private val cartDao = db.cartDao()

    // Tạo đơn hàng
    suspend fun createOrder(username: String): Long {
        val cartItems = cartDao.getCart(username)
        if (cartItems.isEmpty()) return -1

        val total = cartItems.sumOf { it.quantity * 1.0 } // giá sẽ lấy từ Product ở phiên bản hoàn chỉnh

        // Tạo order
        val orderId = orderDao.insert(
            Order(
                username = username,
                totalAmount = total
            )
        )

        // Tạo order item
        val items = cartItems.map {
            OrderItem(
                orderId = orderId,
                productId = it.productId,
                quantity = it.quantity,
                price = it.quantity * 1.0
            )
        }

        orderItemDao.insertAll(items)

        // Xóa giỏ
        cartDao.clear(username)

        return orderId
    }

    // Lấy danh sách đơn của user
    suspend fun getUserOrders(username: String): List<Order> =
        orderDao.getByUser(username)

    // Lấy tất cả đơn (admin)
    suspend fun getAllOrders(): List<Order> =
        orderDao.getAllOrders()

    // Lấy item của đơn
    suspend fun getOrderItems(orderId: Long): List<OrderItem> =
        orderItemDao.getByOrder(orderId)

    // Admin cập nhật trạng thái đơn
    suspend fun updateOrderStatus(order: Order, newStatus: OrderStatus) {
        val updated = order.copy(status = newStatus)
        orderDao.update(updated)
    }

    // User hủy đơn (chỉ khi trạng thái đang xử lý)
    suspend fun cancelOrder(order: Order): Boolean {
        if (order.status == OrderStatus.DELIVERED ||
            order.status == OrderStatus.SHIPPING
        ) {
            return false
        }

        val updated = order.copy(status = OrderStatus.CANCELLED)
        orderDao.update(updated)
        return true
    }
}
