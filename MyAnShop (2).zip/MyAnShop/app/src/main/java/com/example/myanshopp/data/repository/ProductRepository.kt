package com.example.myanshopp.data.repository

import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.Product

class ProductRepository(private val db: AppDatabase) {

    private val productDao = db.productDao()

    suspend fun getAll(): List<Product> = productDao.getAll()

    suspend fun getByCategory(categoryId: Long): List<Product> =
        productDao.getByCategory(categoryId)

    suspend fun getById(id: Long): Product? = productDao.getById(id)

    suspend fun addProduct(product: Product): Long = productDao.insert(product)

    suspend fun updateProduct(product: Product) = productDao.update(product)

    suspend fun deleteProduct(product: Product) = productDao.delete(product)
}
