package com.example.myanshopp.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myanshopp.data.model.CartItem
import com.example.myanshopp.databinding.ItemCartBinding

class CartAdapter(
    private var list: MutableList<CartItem>,
    private val onUpdateQty: (CartItem) -> Unit,
    private val onDelete: (CartItem) -> Unit
) : RecyclerView.Adapter<CartAdapter.VH>() {

    inner class VH(val binding: ItemCartBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemCartBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = list[position]

        holder.binding.txtCartProductName.text = "ID SP: ${item.productId}"
        holder.binding.txtCartQty.text = "SL: ${item.quantity}"

        holder.binding.btnIncrease.setOnClickListener {
            val updated = item.copy(quantity = item.quantity + 1)
            onUpdateQty(updated)
        }

        holder.binding.btnDecrease.setOnClickListener {
            if (item.quantity > 1) {
                val updated = item.copy(quantity = item.quantity - 1)
                onUpdateQty(updated)
            }
        }

        holder.binding.btnDeleteItem.setOnClickListener {
            onDelete(item)
        }
    }

    override fun getItemCount(): Int = list.size

    fun updateData(newList: List<CartItem>) {
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}
