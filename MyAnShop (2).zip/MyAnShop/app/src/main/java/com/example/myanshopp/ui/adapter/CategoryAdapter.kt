package com.example.myanshopp.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myanshopp.data.model.Category
import com.example.myanshopp.databinding.ItemCategoryBinding

class CategoryAdapter(
    private var list: MutableList<Category>,
    private val onClick: (Category) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    inner class VH(val binding: ItemCategoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemCategoryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = list[position]

        holder.binding.txtCategoryName.text = c.name

        holder.binding.root.setOnClickListener {
            onClick(c)
        }
    }

    override fun getItemCount() = list.size

    fun updateData(newList: List<Category>) {
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}
