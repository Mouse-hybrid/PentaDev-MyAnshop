package com.example.myanshopp.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myanshopp.data.model.Order
import com.example.myanshopp.databinding.ItemOrderBinding

class OrderAdapter(
    private var list: MutableList<Order>
) : RecyclerView.Adapter<OrderAdapter.VH>() {

    inner class VH(val binding: ItemOrderBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemOrderBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val order = list[position]

        holder.binding.txtOrderId.text = "Mã đơn: ${order.id}"
        holder.binding.txtOrderTotal.text = "Tổng: ${order.totalAmount} đ"
        holder.binding.txtOrderStatus.text = "Trạng thái: ${order.status}"
    }

    override fun getItemCount(): Int = list.size

    fun updateData(newList: List<Order>) {
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}
