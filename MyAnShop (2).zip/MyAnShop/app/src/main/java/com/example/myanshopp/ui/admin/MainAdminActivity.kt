package com.example.myanshopp.ui.admin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.myanshopp.R
import com.example.myanshopp.databinding.ActivityMainAdminBinding
import com.example.myanshopp.ui.admin.fragment.*

class MainAdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainAdminBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadFragment(AdminProductListFragment())

        binding.adminBottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_admin_products -> loadFragment(AdminProductListFragment())
                R.id.menu_admin_categories -> loadFragment(AdminCategoryFragment())
                R.id.menu_admin_orders -> loadFragment(AdminOrderListFragment())
                R.id.menu_admin_stats -> loadFragment(AdminStatsFragment())
            }
            true
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.admin_container, fragment)
            .commit()
    }
}
