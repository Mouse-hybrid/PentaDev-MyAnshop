package com.example.myanshopp.ui.admin.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myanshopp.data.model.Category
import com.example.myanshopp.databinding.ItemAdminCategoryBinding

class AdminCategoryAdapter(
    private var list: MutableList<Category>,
    private val onEdit: (Category) -> Unit,
    private val onDelete: (Category) -> Unit
) : RecyclerView.Adapter<AdminCategoryAdapter.VH>() {

    inner class VH(val binding: ItemAdminCategoryBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(
            ItemAdminCategoryBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val cat = list[position]
        holder.binding.txtAdminCategoryName.text = cat.name

        holder.binding.btnAdminEditCategory.setOnClickListener { onEdit(cat) }
        holder.binding.btnAdminDeleteCategory.setOnClickListener { onDelete(cat) }
    }

    override fun getItemCount(): Int = list.size

    fun updateCategories(newList: List<Category>) {
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}
