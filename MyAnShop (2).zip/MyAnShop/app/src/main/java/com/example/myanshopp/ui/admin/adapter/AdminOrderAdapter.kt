package com.example.myanshopp.ui.admin.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myanshopp.data.model.Order
import com.example.myanshopp.data.model.OrderStatus
import com.example.myanshopp.databinding.ItemAdminOrderBinding

class AdminOrderAdapter(
    private var list: MutableList<Order>,
    private val onUpdateStatus: (Order, OrderStatus) -> Unit
) : RecyclerView.Adapter<AdminOrderAdapter.VH>() {

    inner class VH(val binding: ItemAdminOrderBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(
            ItemAdminOrderBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val order = list[position]

        holder.binding.txtAdminOrderId.text = "Mã đơn: ${order.id}"
        holder.binding.txtAdminOrderUser.text = "User: ${order.username}"
        holder.binding.txtAdminOrderTotal.text = "Tổng: ${order.totalAmount} đ"
        holder.binding.txtAdminOrderStatus.text = "Trạng thái: ${order.status}"

        holder.binding.btnAdminPending.setOnClickListener {
            onUpdateStatus(order, OrderStatus.PENDING)
        }
        holder.binding.btnAdminShipping.setOnClickListener {
            onUpdateStatus(order, OrderStatus.SHIPPING)
        }
        holder.binding.btnAdminDelivered.setOnClickListener {
            onUpdateStatus(order, OrderStatus.DELIVERED)
        }
        holder.binding.btnAdminCancel.setOnClickListener {
            onUpdateStatus(order, OrderStatus.CANCELLED)
        }
    }

    override fun getItemCount(): Int = list.size

    fun updateOrders(newList: List<Order>) {
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}
