package com.example.myanshopp.ui.admin.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myanshopp.data.model.Product
import com.example.myanshopp.databinding.ItemAdminProductBinding

class AdminProductAdapter(
    private var list: MutableList<Product>,
    private val onEdit: (Product) -> Unit,
    private val onDelete: (Product) -> Unit
) : RecyclerView.Adapter<AdminProductAdapter.VH>() {

    inner class VH(val binding: ItemAdminProductBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(
            ItemAdminProductBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = list[position]

        holder.binding.txtAdminProductName.text = p.name
        holder.binding.txtAdminProductPrice.text = "${p.price} đ"
        holder.binding.txtAdminProductStock.text = "Tồn: ${p.stock}"

        holder.binding.btnAdminEdit.setOnClickListener { onEdit(p) }
        holder.binding.btnAdminDelete.setOnClickListener { onDelete(p) }
    }

    override fun getItemCount() = list.size

    fun updateProducts(newList: List<Product>) {
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}
