package com.example.myanshopp.ui.admin.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.Category
import com.example.myanshopp.data.repository.CategoryRepository
import com.example.myanshopp.databinding.FragmentAdminCategoryBinding
import com.example.myanshopp.ui.admin.adapter.AdminCategoryAdapter
import com.example.myanshopp.ui.viewmodel.CategoryViewModel
import com.example.myanshopp.ui.viewmodel.CategoryViewModelFactory

class AdminCategoryFragment : Fragment() {

    private lateinit var binding: FragmentAdminCategoryBinding
    private lateinit var viewModel: CategoryViewModel
    private lateinit var adapter: AdminCategoryAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAdminCategoryBinding.inflate(inflater, container, false)
        setupViewModel()
        setupRecycler()
        setupListeners()
        return binding.root
    }

    private fun setupViewModel() {
        val repo = CategoryRepository(AppDatabase.getInstance(requireContext()))
        val factory = CategoryViewModelFactory(repo)
        viewModel = ViewModelProvider(this, factory)[CategoryViewModel::class.java]
    }

    private fun setupRecycler() {
        adapter = AdminCategoryAdapter(
            mutableListOf(),
            onEdit = { cat -> editCategory(cat) },
            onDelete = { cat -> viewModel.deleteCategory(cat) }
        )

        binding.recyclerAdminCategory.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerAdminCategory.adapter = adapter

        viewModel.categories.observe(viewLifecycleOwner) {
            adapter.updateCategories(it)
        }

        viewModel.loadCategories()
    }

    private fun setupListeners() {
        binding.btnAddCategory.setOnClickListener {
            val name = binding.edtCategoryName.text.toString()
            if (name.isNotBlank()) {
                viewModel.addCategory(name)
                binding.edtCategoryName.text.clear()
            }
        }
    }

    private fun editCategory(cat: Category) {
        binding.edtCategoryName.setText(cat.name)
        binding.btnAddCategory.setOnClickListener {
            val newName = binding.edtCategoryName.text.toString()
            viewModel.updateCategory(cat.copy(name = newName))
        }
    }
}
