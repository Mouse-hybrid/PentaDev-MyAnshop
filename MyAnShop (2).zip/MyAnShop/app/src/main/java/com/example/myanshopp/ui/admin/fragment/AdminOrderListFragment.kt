package com.example.myanshopp.ui.admin.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.Order
import com.example.myanshopp.data.model.OrderStatus
import com.example.myanshopp.data.repository.OrderRepository
import com.example.myanshopp.databinding.FragmentAdminOrderListBinding
import com.example.myanshopp.ui.admin.adapter.AdminOrderAdapter
import com.example.myanshopp.ui.viewmodel.OrderViewModel
import com.example.myanshopp.ui.viewmodel.OrderViewModelFactory

class AdminOrderListFragment : Fragment() {

    private lateinit var binding: FragmentAdminOrderListBinding
    private lateinit var viewModel: OrderViewModel
    private lateinit var adapter: AdminOrderAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAdminOrderListBinding.inflate(inflater, container, false)
        setupViewModel()
        setupRecycler()
        return binding.root
    }

    private fun setupViewModel() {
        val repo = OrderRepository(AppDatabase.getInstance(requireContext()))
        val factory = OrderViewModelFactory(repo)
        viewModel = ViewModelProvider(this, factory)[OrderViewModel::class.java]
    }

    private fun setupRecycler() {
        adapter = AdminOrderAdapter(
            mutableListOf(),
            onUpdateStatus = { order, status ->
                viewModel.updateOrderStatus(order, status)
            }
        )

        binding.recyclerAdminOrders.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerAdminOrders.adapter = adapter

        viewModel.orders.observe(viewLifecycleOwner) {
            adapter.updateOrders(it)
        }

        viewModel.loadAllOrders()
    }
}
