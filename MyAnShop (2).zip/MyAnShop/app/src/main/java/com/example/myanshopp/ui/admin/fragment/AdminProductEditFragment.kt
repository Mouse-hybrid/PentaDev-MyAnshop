package com.example.myanshopp.ui.admin.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.Product
import com.example.myanshopp.data.repository.ProductRepository
import com.example.myanshopp.databinding.FragmentAdminProductEditBinding
import com.example.myanshopp.ui.viewmodel.ProductViewModel
import com.example.myanshopp.ui.viewmodel.ProductViewModelFactory

class AdminProductEditFragment : Fragment() {

    private lateinit var binding: FragmentAdminProductEditBinding
    private lateinit var viewModel: ProductViewModel
    private var productId: Long? = null

    companion object {
        fun newInstance(id: Long?): AdminProductEditFragment {
            val f = AdminProductEditFragment()
            val b = Bundle()
            if (id != null) b.putLong("id", id)
            f.arguments = b
            return f
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAdminProductEditBinding.inflate(inflater, container, false)
        productId = arguments?.getLong("id")

        setupViewModel()
        setupUI()

        return binding.root
    }

    private fun setupViewModel() {
        val repo = ProductRepository(AppDatabase.getInstance(requireContext()))
        val factory = ProductViewModelFactory(repo)
        viewModel = ViewModelProvider(this, factory)[ProductViewModel::class.java]
    }

    private fun setupUI() {

        // Nếu sửa → load sản phẩm
        productId?.let { id ->
            viewModel.loadProductDetail(id)
            viewModel.productDetail.observe(viewLifecycleOwner) { p ->
                if (p != null) {
                    binding.edtName.setText(p.name)
                    binding.edtPrice.setText(p.price.toString())
                    binding.edtStock.setText(p.stock.toString())
                    binding.edtDescription.setText(p.description)
                }
            }
        }

        binding.btnSave.setOnClickListener {
            val name = binding.edtName.text.toString()
            val price = binding.edtPrice.text.toString().toDouble()
            val stock = binding.edtStock.text.toString().toInt()
            val desc = binding.edtDescription.text.toString()

            val product = Product(
                id = productId ?: 0,
                name = name,
                price = price,
                stock = stock,
                description = desc,
                categoryId = 1 // default nếu bạn chưa làm danh mục
            )

            if (productId == null)
                viewModel.addProduct(product)
            else
                viewModel.updateProduct(product)

            parentFragmentManager.popBackStack()
        }
    }
}
