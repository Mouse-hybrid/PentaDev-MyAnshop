package com.example.myanshopp.ui.admin.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.repository.ProductRepository
import com.example.myanshopp.databinding.FragmentAdminProductListBinding
import com.example.myanshopp.ui.admin.adapter.AdminProductAdapter
import com.example.myanshopp.ui.viewmodel.ProductViewModel
import com.example.myanshopp.ui.viewmodel.ProductViewModelFactory
import com.example.myanshopp.R


class AdminProductListFragment : Fragment() {

    private lateinit var binding: FragmentAdminProductListBinding
    private lateinit var viewModel: ProductViewModel
    private lateinit var adapter: AdminProductAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAdminProductListBinding.inflate(inflater, container, false)
        setupViewModel()
        setupRecycler()
        setupListeners()
        return binding.root
    }

    private fun setupViewModel() {
        val repo = ProductRepository(AppDatabase.getInstance(requireContext()))
        val factory = ProductViewModelFactory(repo)
        viewModel = ViewModelProvider(this, factory)[ProductViewModel::class.java]
    }

    private fun setupRecycler() {
        adapter = AdminProductAdapter(
            mutableListOf(),
            onEdit = { product ->
                val fragment = AdminProductEditFragment.newInstance(product.id)
                parentFragmentManager.beginTransaction()
                    .replace(R.id.admin_container, fragment)
                    .addToBackStack(null)
                    .commit()
            },
            onDelete = { product ->
                viewModel.deleteProduct(product)
            }
        )

        binding.recyclerAdminProducts.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerAdminProducts.adapter = adapter

        viewModel.products.observe(viewLifecycleOwner) {
            adapter.updateProducts(it)
        }

        viewModel.loadAllProducts()
    }

    private fun setupListeners() {
        binding.btnAddProduct.setOnClickListener {
            val fragment = AdminProductEditFragment.newInstance(null)
            parentFragmentManager.beginTransaction()
                .replace(R.id.admin_container, fragment)
                .addToBackStack(null)
                .commit()
        }
    }
}
