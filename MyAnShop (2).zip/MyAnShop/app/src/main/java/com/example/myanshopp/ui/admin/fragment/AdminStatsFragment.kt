package com.example.myanshopp.ui.admin.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.myanshopp.databinding.FragmentAdminStatsBinding

class AdminStatsFragment : Fragment() {

    private lateinit var binding: FragmentAdminStatsBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAdminStatsBinding.inflate(inflater, container, false)
        binding.txtStats.text = "Thống kê sẽ được thêm sau"
        return binding.root
    }
}
