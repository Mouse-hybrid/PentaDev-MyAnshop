package com.example.myanshopp.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.ViewModelProvider
import com.example.myanshopp.R
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.repository.AuthRepository
import com.example.myanshopp.ui.admin.MainAdminActivity
import com.example.myanshopp.ui.user.MainUserActivity
import com.example.myanshopp.ui.viewmodel.AuthViewModel
import com.example.myanshopp.ui.viewmodel.AuthViewModelFactory

class LoginActivity : ComponentActivity() {

    private lateinit var viewModel: AuthViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val db = AppDatabase.getInstance(this)
        val repo = AuthRepository(db)
        viewModel = ViewModelProvider(
            this,
            AuthViewModelFactory(repo)
        )[AuthViewModel::class.java]

        val edtUsername = findViewById<EditText>(R.id.edtUsername)
        val edtPassword = findViewById<EditText>(R.id.edtPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val txtRegister = findViewById<TextView>(R.id.txtGoRegister)

        btnLogin.setOnClickListener {
            val username = edtUsername.text.toString().trim()
            val password = edtPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đủ thông tin", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewModel.login(username, password)
        }

        txtRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.loginResult.observe(this) { user ->
            if (user == null) {
                Toast.makeText(this, "Sai tài khoản hoặc mật khẩu", Toast.LENGTH_SHORT).show()
                return@observe
            }

            // Navigate theo quyền
            if (user.isAdmin) {
                startActivity(Intent(this, MainAdminActivity::class.java))
            } else {
                val intent = Intent(this, MainUserActivity::class.java)
                intent.putExtra("username", user.username)
                startActivity(intent)
            }
            finish()
        }
    }
}
