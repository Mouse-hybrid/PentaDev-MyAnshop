package com.example.myanshopp.ui.auth

import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.ViewModelProvider
import com.example.myanshopp.R
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.User
import com.example.myanshopp.data.repository.AuthRepository
import com.example.myanshopp.ui.viewmodel.AuthViewModel
import com.example.myanshopp.ui.viewmodel.AuthViewModelFactory

class RegisterActivity : ComponentActivity() {

    private lateinit var viewModel: AuthViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val db = AppDatabase.getInstance(this)
        val repo = AuthRepository(db)
        viewModel = ViewModelProvider(
            this,
            AuthViewModelFactory(repo)
        )[AuthViewModel::class.java]

        val edtUsername = findViewById<EditText>(R.id.edtUsername)
        val edtName = findViewById<EditText>(R.id.edtName)
        val edtPassword = findViewById<EditText>(R.id.edtPassword)
        val edtPhone = findViewById<EditText>(R.id.edtPhone)
        val edtAddress = findViewById<EditText>(R.id.edtAddress)
        val btnRegister = findViewById<Button>(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val username = edtUsername.text.toString().trim()
            val name = edtName.text.toString().trim()
            val password = edtPassword.text.toString().trim()
            val phone = edtPhone.text.toString().trim()
            val address = edtAddress.text.toString().trim()

            if (username.isEmpty() || name.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đủ thông tin", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val user = User(
                username = username,
                displayName = name,
                password = password,
                phone = phone,
                address = address,
                isAdmin = false
            )

            viewModel.register(user)
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.registerSuccess.observe(this) { success ->
            if (success) {
                Toast.makeText(this, "Đăng ký thành công", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Tài khoản đã tồn tại", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
