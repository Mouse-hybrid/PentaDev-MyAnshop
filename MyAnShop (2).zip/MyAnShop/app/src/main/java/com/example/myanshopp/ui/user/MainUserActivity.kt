package com.example.myanshopp.ui.user

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.myanshopp.R
import com.example.myanshopp.databinding.ActivityMainUserBinding
import com.example.myanshopp.ui.user.fragment.*

class MainUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainUserBinding
    private var username: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        username = intent.getStringExtra("username") ?: ""

        setupBottomNav()
        loadFragment(HomeFragment.newInstance(username))
    }

    private fun setupBottomNav() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_home -> loadFragment(HomeFragment.newInstance(username))
                R.id.menu_category -> loadFragment(CategoryFragment())
                R.id.menu_cart -> loadFragment(CartFragment.newInstance(username))
                R.id.menu_orders -> loadFragment(OrdersFragment.newInstance(username))
                R.id.menu_profile -> loadFragment(ProfileFragment.newInstance(username))
            }
            true
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.main_container, fragment)
            .commit()
    }
}
