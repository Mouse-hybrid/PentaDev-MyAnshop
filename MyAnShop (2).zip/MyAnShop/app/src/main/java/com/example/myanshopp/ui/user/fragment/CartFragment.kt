package com.example.myanshopp.ui.user.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.repository.CartRepository
import com.example.myanshopp.data.repository.OrderRepository
import com.example.myanshopp.databinding.FragmentCartBinding
import com.example.myanshopp.ui.user.adapter.CartAdapter
import com.example.myanshopp.ui.viewmodel.CartViewModel
import com.example.myanshopp.ui.viewmodel.CartViewModelFactory
import com.example.myanshopp.ui.viewmodel.OrderViewModel
import com.example.myanshopp.ui.viewmodel.OrderViewModelFactory

class CartFragment : Fragment() {

    private lateinit var binding: FragmentCartBinding
    private lateinit var cartViewModel: CartViewModel
    private lateinit var orderViewModel: OrderViewModel
    private lateinit var adapter: CartAdapter

    private var username: String = ""

    companion object {
        fun newInstance(username: String): CartFragment {
            val f = CartFragment()
            val b = Bundle()
            b.putString("username", username)
            f.arguments = b
            return f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        username = arguments?.getString("username") ?: ""
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentCartBinding.inflate(inflater, container, false)

        setupViewModels()
        setupRecycler()

        return binding.root
    }

    private fun setupViewModels() {
        val db = AppDatabase.getInstance(requireContext())

        cartViewModel = ViewModelProvider(
            this,
            CartViewModelFactory(CartRepository(db))
        )[CartViewModel::class.java]

        orderViewModel = ViewModelProvider(
            this,
            OrderViewModelFactory(OrderRepository(db))
        )[OrderViewModel::class.java]
    }

    private fun setupRecycler() {
        adapter = CartAdapter(
            mutableListOf(),
            onUpdateQty = { item ->
                cartViewModel.updateItem(item, username)
            },
            onDelete = { item ->
                cartViewModel.remove(item.id, username)
            }
        )

        binding.recyclerCart.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerCart.adapter = adapter

        cartViewModel.cart.observe(viewLifecycleOwner) {
            adapter.updateData(it)
        }

        cartViewModel.loadCart(username)

        binding.btnCheckout.setOnClickListener {
            orderViewModel.createOrder(username)
            Toast.makeText(requireContext(), "Đặt hàng thành công!", Toast.LENGTH_SHORT).show()
            cartViewModel.clear(username)
        }
    }
}
