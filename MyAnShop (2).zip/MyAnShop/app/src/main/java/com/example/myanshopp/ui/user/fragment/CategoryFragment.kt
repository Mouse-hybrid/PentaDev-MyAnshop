package com.example.myanshopp.ui.user.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.repository.CategoryRepository
import com.example.myanshopp.databinding.FragmentCategoryBinding
import com.example.myanshopp.ui.user.adapter.CategoryAdapter
import com.example.myanshopp.ui.viewmodel.CategoryViewModel
import com.example.myanshopp.ui.viewmodel.CategoryViewModelFactory

class CategoryFragment : Fragment() {

    private lateinit var binding: FragmentCategoryBinding
    private lateinit var viewModel: CategoryViewModel
    private lateinit var adapter: CategoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCategoryBinding.inflate(inflater, container, false)

        setupViewModel()
        setupRecycler()

        return binding.root
    }

    private fun setupViewModel() {
        val repo = CategoryRepository(AppDatabase.getInstance(requireContext()))
        val factory = CategoryViewModelFactory(repo)
        viewModel = ViewModelProvider(this, factory)[CategoryViewModel::class.java]
    }

    private fun setupRecycler() {
        adapter = CategoryAdapter(mutableListOf()) { category ->
            // Mở danh sách sản phẩm theo danh mục
            val fragment = HomeFragment() // hoặc ProductListByCategoryFragment nếu bạn tách riêng
            val bundle = Bundle()
            bundle.putLong("categoryId", category.id)
            fragment.arguments = bundle

            parentFragmentManager.beginTransaction()
                .replace(R.id.main_container, fragment)
                .addToBackStack(null)
                .commit()
        }

        binding.recyclerCategory.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerCategory.adapter = adapter

        viewModel.categories.observe(viewLifecycleOwner) {
            adapter.updateData(it)
        }

        viewModel.loadCategories()
    }
}
