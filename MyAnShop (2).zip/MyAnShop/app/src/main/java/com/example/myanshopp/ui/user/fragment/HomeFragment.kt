package com.example.myanshopp.ui.user.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.repository.ProductRepository
import com.example.myanshopp.databinding.FragmentHomeBinding
import com.example.myanshopp.ui.user.adapter.ProductAdapter
import com.example.myanshopp.ui.viewmodel.ProductViewModel
import com.example.myanshopp.ui.viewmodel.ProductViewModelFactory

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var viewModel: ProductViewModel
    private lateinit var adapter: ProductAdapter
    private var username: String = ""

    companion object {
        fun newInstance(username: String): HomeFragment {
            val f = HomeFragment()
            val b = Bundle()
            b.putString("username", username)
            f.arguments = b
            return f
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        username = arguments?.getString("username") ?: ""
        setupViewModel()
        setupRecyclerView()
        return binding.root
    }

    private fun setupViewModel() {
        val repo = ProductRepository(AppDatabase.getInstance(requireContext()))
        val factory = ProductViewModelFactory(repo)
        viewModel = ViewModelProvider(this, factory)[ProductViewModel::class.java]
    }

    private fun setupRecyclerView() {
        adapter = ProductAdapter(mutableListOf(), onItemClick = { product ->
            val fragment = ProductDetailFragment.newInstance(product.id, username)
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.main_container, fragment)
                .addToBackStack(null)
                .commit()
        })

        binding.recyclerHome.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerHome.adapter = adapter

        observeViewModel()
        viewModel.loadAllProducts()
    }

    private fun observeViewModel() {
        viewModel.products.observe(viewLifecycleOwner) {
            adapter.updateData(it)
        }
    }
}
