package com.example.myanshopp.ui.user.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.repository.OrderRepository
import com.example.myanshopp.databinding.FragmentOrdersBinding
import com.example.myanshopp.ui.user.adapter.OrderAdapter
import com.example.myanshopp.ui.viewmodel.OrderViewModel
import com.example.myanshopp.ui.viewmodel.OrderViewModelFactory

class OrdersFragment : Fragment() {

    private lateinit var binding: FragmentOrdersBinding
    private lateinit var viewModel: OrderViewModel
    private lateinit var adapter: OrderAdapter

    private var username: String = ""

    companion object {
        fun newInstance(username: String): OrdersFragment {
            val f = OrdersFragment()
            val b = Bundle()
            b.putString("username", username)
            f.arguments = b
            return f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        username = arguments?.getString("username") ?: ""
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentOrdersBinding.inflate(inflater, container, false)

        setupViewModel()
        setupRecycler()

        return binding.root
    }

    private fun setupViewModel() {
        val repo = OrderRepository(AppDatabase.getInstance(requireContext()))
        viewModel = ViewModelProvider(
            this,
            OrderViewModelFactory(repo)
        )[OrderViewModel::class.java]
    }

    private fun setupRecycler() {
        adapter = OrderAdapter(mutableListOf())
        binding.recyclerOrders.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerOrders.adapter = adapter

        viewModel.orders.observe(viewLifecycleOwner) {
            adapter.updateData(it)
        }

        viewModel.loadUserOrders(username)
    }
}
