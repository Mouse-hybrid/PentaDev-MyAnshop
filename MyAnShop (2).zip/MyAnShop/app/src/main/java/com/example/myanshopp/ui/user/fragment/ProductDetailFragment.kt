package com.example.myanshopp.ui.user.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.repository.CartRepository
import com.example.myanshopp.data.repository.ProductRepository
import com.example.myanshopp.databinding.FragmentProductDetailBinding
import com.example.myanshopp.ui.viewmodel.CartViewModel
import com.example.myanshopp.ui.viewmodel.CartViewModelFactory
import com.example.myanshopp.ui.viewmodel.ProductViewModel
import com.example.myanshopp.ui.viewmodel.ProductViewModelFactory

class ProductDetailFragment : Fragment() {

    private lateinit var binding: FragmentProductDetailBinding
    private lateinit var viewModel: ProductViewModel
    private lateinit var cartViewModel: CartViewModel

    private var productId: Long = 0
    private var username: String = ""

    companion object {
        fun newInstance(id: Long, username: String): ProductDetailFragment {
            val f = ProductDetailFragment()
            val b = Bundle()
            b.putLong("id", id)
            b.putString("username", username)
            f.arguments = b
            return f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        productId = arguments?.getLong("id") ?: 0
        username = arguments?.getString("username") ?: ""
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentProductDetailBinding.inflate(inflater, container, false)

        setupViewModel()
        viewModel.loadProductDetail(productId)

        return binding.root
    }

    private fun setupViewModel() {
        val db = AppDatabase.getInstance(requireContext())

        val productRepo = ProductRepository(db)
        viewModel = ViewModelProvider(this, ProductViewModelFactory(productRepo))[ProductViewModel::class.java]

        val cartRepo = CartRepository(db)
        cartViewModel = ViewModelProvider(this, CartViewModelFactory(cartRepo))[CartViewModel::class.java]

        viewModel.productDetail.observe(viewLifecycleOwner) { p ->
            if (p != null) {
                binding.txtDetailName.text = p.name
                binding.txtDetailPrice.text = "${p.price} đ"
                binding.txtDetailDesc.text = p.description

                binding.btnAddToCart.setOnClickListener {
                    cartViewModel.addToCart(username, p.id)
                    Toast.makeText(requireContext(), "Đã thêm vào giỏ", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
