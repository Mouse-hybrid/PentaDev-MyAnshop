package com.example.myanshopp.ui.user.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.myanshopp.data.db.AppDatabase
import com.example.myanshopp.data.model.User
import com.example.myanshopp.data.repository.AuthRepository
import com.example.myanshopp.databinding.FragmentProfileBinding
import com.example.myanshopp.ui.viewmodel.AuthViewModel
import com.example.myanshopp.ui.viewmodel.AuthViewModelFactory

class ProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding
    private lateinit var viewModel: AuthViewModel
    private var username: String = ""

    companion object {
        fun newInstance(username: String): ProfileFragment {
            val f = ProfileFragment()
            val b = Bundle()
            b.putString("username", username)
            f.arguments = b
            return f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        username = arguments?.getString("username") ?: ""
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentProfileBinding.inflate(inflater, container, false)

        setupViewModel()
        loadProfile()

        binding.btnSaveProfile.setOnClickListener {
            saveProfile()
        }

        return binding.root
    }

    private fun setupViewModel() {
        val repo = AuthRepository(AppDatabase.getInstance(requireContext()))
        val factory = AuthViewModelFactory(repo)
        viewModel = ViewModelProvider(this, factory)[AuthViewModel::class.java]
    }

    private fun loadProfile() {
        viewModel.login(username, "") // dùng login() để lấy user, vì repository có getUser()

        viewModel.loginResult.observe(viewLifecycleOwner) { user ->
            if (user != null) {
                binding.edtProfileName.setText(user.displayName)
                binding.edtProfilePhone.setText(user.phone ?: "")
                binding.edtProfileAddress.setText(user.address ?: "")
            }
        }
    }

    private fun saveProfile() {
        val name = binding.edtProfileName.text.toString()
        val phone = binding.edtProfilePhone.text.toString()
        val address = binding.edtProfileAddress.text.toString()

        val user = User(
            username = username,
            displayName = name,
            phone = phone,
            address = address,
            password = "",
            isAdmin = false
        )

        viewModel.updateProfile(user)

        Toast.makeText(requireContext(), "Cập nhật thành công!", Toast.LENGTH_SHORT).show()
    }
}
