package com.example.myanshopp.ui.viewmodel

import androidx.lifecycle.*
import com.example.myanshopp.data.model.User
import com.example.myanshopp.data.repository.AuthRepository
import kotlinx.coroutines.launch

class AuthViewModel(private val repo: AuthRepository) : ViewModel() {

    private val _loginResult = MutableLiveData<User?>()
    val loginResult: LiveData<User?> = _loginResult

    private val _registerSuccess = MutableLiveData<Boolean>()
    val registerSuccess: LiveData<Boolean> = _registerSuccess

    // Đăng nhập
    fun login(username: String, password: String) {
        viewModelScope.launch {
            val result = repo.login(username, password)
            _loginResult.postValue(result)
        }
    }

    // Đăng ký
    fun register(user: User) {
        viewModelScope.launch {
            val success = repo.register(user)
            _registerSuccess.postValue(success)
        }
    }

    // Update profile
    fun updateProfile(user: User) {
        viewModelScope.launch {
            repo.updateProfile(user)
        }
    }
}
