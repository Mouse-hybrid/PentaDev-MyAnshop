package com.example.myanshopp.ui.viewmodel

import androidx.lifecycle.*
import com.example.myanshopp.data.model.CartItem
import com.example.myanshopp.data.repository.CartRepository
import kotlinx.coroutines.launch

class CartViewModel(private val repo: CartRepository) : ViewModel() {

    private val _cart = MutableLiveData<List<CartItem>>()
    val cart: LiveData<List<CartItem>> = _cart

    fun loadCart(username: String) {
        viewModelScope.launch {
            _cart.postValue(repo.getCart(username))
        }
    }

    fun addToCart(username: String, productId: Long, qty: Int = 1) {
        viewModelScope.launch {
            repo.addToCart(username, productId, qty)
            loadCart(username)
        }
    }

    fun updateItem(item: CartItem, username: String) {
        viewModelScope.launch {
            repo.updateItem(item)
            loadCart(username)
        }
    }

    fun remove(itemId: Long, username: String) {
        viewModelScope.launch {
            repo.remove(itemId)
            loadCart(username)
        }
    }

    fun clear(username: String) {
        viewModelScope.launch {
            repo.clear(username)
            loadCart(username)
        }
    }
}
