package com.example.myanshopp.ui.viewmodel

import androidx.lifecycle.*
import com.example.myanshopp.data.model.Category
import com.example.myanshopp.data.repository.CategoryRepository
import kotlinx.coroutines.launch

class CategoryViewModel(private val repo: CategoryRepository) : ViewModel() {

    private val _categories = MutableLiveData<List<Category>>()
    val categories: LiveData<List<Category>> = _categories

    fun loadCategories() {
        viewModelScope.launch {
            _categories.postValue(repo.getAll())
        }
    }

    fun addCategory(name: String) {
        viewModelScope.launch {
            repo.addCategory(name)
            loadCategories()
        }
    }

    fun updateCategory(cat: Category) {
        viewModelScope.launch {
            repo.updateCategory(cat)
            loadCategories()
        }
    }

    fun deleteCategory(cat: Category) {
        viewModelScope.launch {
            repo.deleteCategory(cat)
            loadCategories()
        }
    }
}

class CategoryViewModelFactory(
    private val repo: CategoryRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CategoryViewModel::class.java)) {
            return CategoryViewModel(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
