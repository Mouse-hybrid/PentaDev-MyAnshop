package com.example.myanshopp.ui.viewmodel

import androidx.lifecycle.*
import com.example.myanshopp.data.model.Order
import com.example.myanshopp.data.model.OrderItem
import com.example.myanshopp.data.model.OrderStatus
import com.example.myanshopp.data.repository.OrderRepository
import kotlinx.coroutines.launch

class OrderViewModel(private val repo: OrderRepository) : ViewModel() {

    private val _orders = MutableLiveData<List<Order>>()
    val orders: LiveData<List<Order>> = _orders

    private val _orderItems = MutableLiveData<List<OrderItem>>()
    val orderItems: LiveData<List<OrderItem>> = _orderItems

    private val _newOrderId = MutableLiveData<Long>()
    val newOrderId: LiveData<Long> = _newOrderId

    // Tạo đơn hàng
    fun createOrder(username: String) {
        viewModelScope.launch {
            val orderId = repo.createOrder(username)
            _newOrderId.postValue(orderId)
        }
    }

    // Load list đơn hàng theo user
    fun loadUserOrders(username: String) {
        viewModelScope.launch {
            _orders.postValue(repo.getUserOrders(username))
        }
    }

    // Admin load tất cả đơn
    fun loadAllOrders() {
        viewModelScope.launch {
            _orders.postValue(repo.getAllOrders())
        }
    }

    // Load item của đơn hàng
    fun loadOrderItems(orderId: Long) {
        viewModelScope.launch {
            _orderItems.postValue(repo.getOrderItems(orderId))
        }
    }

    // Admin thay đổi trạng thái đơn
    fun updateOrderStatus(order: Order, status: OrderStatus) {
        viewModelScope.launch {
            repo.updateOrderStatus(order, status)
            loadAllOrders()
        }
    }

    // User hủy đơn
    fun cancelOrder(order: Order) {
        viewModelScope.launch {
            repo.cancelOrder(order)
            loadUserOrders(order.username)
        }
    }
}
