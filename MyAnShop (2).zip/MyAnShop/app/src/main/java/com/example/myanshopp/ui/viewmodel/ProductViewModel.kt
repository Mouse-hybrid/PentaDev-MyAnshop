package com.example.myanshopp.ui.viewmodel

import androidx.lifecycle.*
import com.example.myanshopp.data.model.Product
import com.example.myanshopp.data.repository.ProductRepository
import kotlinx.coroutines.launch

class ProductViewModel(private val repo: ProductRepository) : ViewModel() {

    private val _products = MutableLiveData<List<Product>>(emptyList())
    val products: LiveData<List<Product>> = _products

    private val _productDetail = MutableLiveData<Product?>()
    val productDetail: LiveData<Product?> = _productDetail

    private val _loading = MutableLiveData<Boolean>(false)
    val loading: LiveData<Boolean> = _loading

    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error

    // Load tất cả sản phẩm
    fun loadAllProducts() {
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val list = repo.getAll()
                _products.postValue(list)
            } catch (t: Throwable) {
                _error.postValue(t.message ?: "Lỗi khi load sản phẩm")
            } finally {
                _loading.postValue(false)
            }
        }
    }

    // Load theo danh mục
    fun loadProductsByCategory(categoryId: Long) {
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val list = repo.getByCategory(categoryId)
                _products.postValue(list)
            } catch (t: Throwable) {
                _error.postValue(t.message ?: "Lỗi khi load sản phẩm theo danh mục")
            } finally {
                _loading.postValue(false)
            }
        }
    }

    // Tìm kiếm theo tên (client-side)
    fun searchProducts(query: String) {
        val current = _products.value ?: emptyList()
        if (query.isBlank()) {
            // nếu muốn reload từ DB thay vì filter trên bộ nhớ thì gọi loadAllProducts()
            _products.postValue(current)
            return
        }
        val filtered = current.filter {
            it.name.contains(query, ignoreCase = true) ||
                    it.description.contains(query, ignoreCase = true)
        }
        _products.postValue(filtered)
    }

    // Load chi tiết sản phẩm
    fun loadProductDetail(id: Long) {
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val p = repo.getById(id)
                _productDetail.postValue(p)
            } catch (t: Throwable) {
                _error.postValue(t.message ?: "Lỗi khi load chi tiết sản phẩm")
            } finally {
                _loading.postValue(false)
            }
        }
    }

    // CRUD: add / update / delete (Admin)
    fun addProduct(product: Product) {
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                repo.addProduct(product)
                loadAllProducts()
            } catch (t: Throwable) {
                _error.postValue(t.message ?: "Lỗi khi thêm sản phẩm")
            } finally {
                _loading.postValue(false)
            }
        }
    }

    fun updateProduct(product: Product) {
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                repo.updateProduct(product)
                loadAllProducts()
            } catch (t: Throwable) {
                _error.postValue(t.message ?: "Lỗi khi cập nhật sản phẩm")
            } finally {
                _loading.postValue(false)
            }
        }
    }

    fun deleteProduct(product: Product) {
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                repo.deleteProduct(product)
                loadAllProducts()
            } catch (t: Throwable) {
                _error.postValue(t.message ?: "Lỗi khi xóa sản phẩm")
            } finally {
                _loading.postValue(false)
            }
        }
    }

    // Clear error
    fun clearError() {
        _error.value = null
    }
}

/**
 * Factory để dùng với ViewModelProvider
 */
class ProductViewModelFactory(private val repo: ProductRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProductViewModel::class.java)) {
            return ProductViewModel(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
