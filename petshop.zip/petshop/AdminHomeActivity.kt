package com.example.petshop

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AdminHomeActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_home)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val toolbar: Toolbar = findViewById(R.id.toolbar_admin)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Admin Dashboard"

        drawerLayout = findViewById(R.id.drawer_layout_admin)
        val navView: NavigationView = findViewById(R.id.nav_view_admin)
        navView.setNavigationItemSelectedListener(this)

        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        bottomNavigationView = findViewById(R.id.bottom_nav_view)
        bottomNavigationView.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.navigation_products -> replaceFragment(AdminProductsFragment())
                R.id.navigation_categories -> replaceFragment(AdminCategoriesFragment())
                R.id.navigation_orders -> replaceFragment(AdminOrdersFragment())
                R.id.navigation_stats -> replaceFragment(AdminStatsFragment())
            }
            true
        }

        if (savedInstanceState == null) {
            replaceFragment(AdminProductsFragment())
            bottomNavigationView.selectedItemId = R.id.navigation_products
        }
        
        updateNavHeader()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_admin_profile -> startActivity(Intent(this, AdminProfileActivity::class.java))
            R.id.nav_admin_logout -> {
                auth.signOut()
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun updateNavHeader() {
        val headerView: View = findViewById<NavigationView>(R.id.nav_view_admin).getHeaderView(0)
        val navUsername: TextView = headerView.findViewById(R.id.nav_header_admin_name)
        val navEmail: TextView = headerView.findViewById(R.id.nav_header_admin_email)
        
        val user = auth.currentUser
        if (user != null) {
            navEmail.text = user.email
             db.collection("users").document(user.uid).get().addOnSuccessListener {
                if(it != null && it.exists()){
                    navUsername.text = it.getString("name")
                }
             }
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.nav_host_fragment_admin, fragment).commit()
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}