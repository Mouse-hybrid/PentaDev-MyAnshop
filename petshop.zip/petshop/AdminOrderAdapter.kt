package com.example.petshop

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class AdminOrderAdapter(private val orderList: List<Order>) : RecyclerView.Adapter<AdminOrderAdapter.OrderViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.order_item_admin, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orderList[position]
        holder.bind(order)
    }

    override fun getItemCount(): Int = orderList.size

    class OrderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val orderId: TextView = itemView.findViewById(R.id.tv_order_id)
        private val orderDate: TextView = itemView.findViewById(R.id.tv_order_date)
        private val orderTotal: TextView = itemView.findViewById(R.id.tv_order_total)
        private val orderStatus: TextView = itemView.findViewById(R.id.tv_order_status)

        fun bind(order: Order) {
            orderId.text = "Order #${order.orderId.take(6)}..."
            orderDate.text = order.createdAt?.let { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(it) } ?: "No date"
            orderTotal.text = "Total: $${String.format("%.2f", order.totalPrice)}"
            orderStatus.text = order.status

            // Set status color
            when (order.status) {
                "Pending" -> orderStatus.setBackgroundColor(Color.parseColor("#FFA500")) // Orange
                "Processing" -> orderStatus.setBackgroundColor(Color.parseColor("#1E90FF")) // DodgerBlue
                "Shipped" -> orderStatus.setBackgroundColor(Color.parseColor("#32CD32")) // LimeGreen
                "Completed" -> orderStatus.setBackgroundColor(Color.parseColor("#808080")) // Gray
                else -> orderStatus.setBackgroundColor(Color.LTGRAY)
            }

            itemView.setOnClickListener {
                val context = itemView.context
                val intent = Intent(context, AdminOrderDetailActivity::class.java).apply {
                    putExtra("ORDER_DETAIL", order)
                }
                context.startActivity(intent)
            }
        }
    }
}