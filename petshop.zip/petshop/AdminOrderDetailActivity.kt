package com.example.petshop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore

class AdminOrderDetailActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private var currentOrder: Order? = null
    private lateinit var statusSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_order_detail)

        db = FirebaseFirestore.getInstance()
        statusSpinner = findViewById(R.id.spinner_order_status)
        
        currentOrder = intent.getParcelableExtra("ORDER_DETAIL")
        if (currentOrder == null) {
            Toast.makeText(this, "Error: Order not found.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        setupViews()
        setupStatusSpinner()

        findViewById<Button>(R.id.btn_update_status).setOnClickListener {
            updateOrderStatus()
        }
    }

    private fun setupViews() {
        findViewById<TextView>(R.id.tv_detail_order_id).text = "Order #${currentOrder!!.orderId.take(8)}..."
        findViewById<TextView>(R.id.tv_detail_address).text = currentOrder!!.address
        findViewById<TextView>(R.id.tv_detail_phone).text = currentOrder!!.phone
        findViewById<TextView>(R.id.tv_detail_total).text = "Total: $${String.format("%.2f", currentOrder!!.totalPrice)}"

        val itemsRecyclerView: RecyclerView = findViewById(R.id.recycler_view_order_items)
        itemsRecyclerView.layoutManager = LinearLayoutManager(this)
        itemsRecyclerView.adapter = SimpleCartAdapter(currentOrder!!.items)
    }

    private fun setupStatusSpinner() {
        val statusOptions = listOf("Pending", "Processing", "Shipped", "Completed", "Cancelled")
        // Use the custom layout for both the spinner and the dropdown
        val adapter = ArrayAdapter(this, R.layout.spinner_item_black, statusOptions)
        adapter.setDropDownViewResource(R.layout.spinner_item_black)
        statusSpinner.adapter = adapter

        val currentStatusPosition = statusOptions.indexOf(currentOrder!!.status)
        if (currentStatusPosition >= 0) {
            statusSpinner.setSelection(currentStatusPosition)
        }
    }

    private fun updateOrderStatus() {
        val newStatus = statusSpinner.selectedItem.toString()
        db.collection("orders").document(currentOrder!!.orderId)
            .update("status", newStatus)
            .addOnSuccessListener {
                Toast.makeText(this, "Order status updated successfully!", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to update status: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

// A simple adapter just to display items, with its own ViewHolder.
class SimpleCartAdapter(private val items: List<CartItem>) : RecyclerView.Adapter<SimpleCartAdapter.SimpleCartViewHolder>() {

    inner class SimpleCartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val productName: TextView = itemView.findViewById(R.id.tv_cart_product_name)
        private val productPrice: TextView = itemView.findViewById(R.id.tv_cart_product_price)
        private val productImage: ImageView = itemView.findViewById(R.id.img_cart_product)
        private val quantity: TextView = itemView.findViewById(R.id.tv_quantity)

        fun bind(item: CartItem) {
            productName.text = item.name
            productPrice.text = "$${String.format("%.2f", item.price)}"
            quantity.text = item.quantity.toString()

            if (item.imageUrl.isNotEmpty()) {
                Glide.with(itemView.context).load(item.imageUrl).centerCrop().into(productImage)
            }

            itemView.findViewById<Button>(R.id.btn_increase_quantity).isEnabled = false
            itemView.findViewById<Button>(R.id.btn_decrease_quantity).isEnabled = false
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SimpleCartViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.cart_item, parent, false)
        return SimpleCartViewHolder(view)
    }

    override fun onBindViewHolder(holder: SimpleCartViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size
}