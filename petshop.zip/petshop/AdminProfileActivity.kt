package com.example.petshop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth

class AdminProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_profile)

        val tvAdminEmail: TextView = findViewById(R.id.tv_admin_email)
        tvAdminEmail.text = FirebaseAuth.getInstance().currentUser?.email ?: "No email found"
    }
}