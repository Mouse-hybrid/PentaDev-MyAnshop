package com.example.petshop

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore
import java.text.NumberFormat
import java.util.Locale

class AdminStatsFragment : Fragment() {

    private lateinit var db: FirebaseFirestore

    private lateinit var tvTotalRevenue: TextView
    private lateinit var tvTotalOrders: TextView
    private lateinit var tvTotalProducts: TextView
    private lateinit var tvTotalUsers: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_admin_stats, container, false)

        db = FirebaseFirestore.getInstance()

        tvTotalRevenue = view.findViewById(R.id.tv_total_revenue)
        tvTotalOrders = view.findViewById(R.id.tv_total_orders)
        tvTotalProducts = view.findViewById(R.id.tv_total_products)
        tvTotalUsers = view.findViewById(R.id.tv_total_users)

        fetchStatistics()

        return view
    }

    private fun fetchStatistics() {
        // Fetch Total Revenue and Total Orders
        db.collection("orders").get()
            .addOnSuccessListener { orderSnapshot ->
                val totalOrders = orderSnapshot.size()
                val totalRevenue = orderSnapshot.documents.sumOf { it.getDouble("totalPrice") ?: 0.0 }
                
                val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "US"))
                tvTotalRevenue.text = currencyFormat.format(totalRevenue)
                tvTotalOrders.text = totalOrders.toString()
            }

        // Fetch Total Products
        db.collection("products").get()
            .addOnSuccessListener { productSnapshot ->
                tvTotalProducts.text = productSnapshot.size().toString()
            }

        // Fetch Total Users
        db.collection("users").get()
            .addOnSuccessListener { userSnapshot ->
                tvTotalUsers.text = userSnapshot.size().toString()
            }
    }
}