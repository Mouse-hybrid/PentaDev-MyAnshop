package com.example.petshop

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip

class CustomerCategoryAdapter(
    private val categoryList: List<Category>,
    private val onCategoryClick: (String) -> Unit
) : RecyclerView.Adapter<CustomerCategoryAdapter.CategoryViewHolder>() {

    private var selectedPosition = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val chip = LayoutInflater.from(parent.context)
            .inflate(R.layout.customer_category_item, parent, false) as Chip
        return CategoryViewHolder(chip)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        holder.bind(categoryList[position], position)
    }

    override fun getItemCount(): Int = categoryList.size

    inner class CategoryViewHolder(private val chip: Chip) : RecyclerView.ViewHolder(chip) {
        fun bind(category: Category, position: Int) {
            chip.text = category.name
            chip.isChecked = position == selectedPosition

            chip.setOnClickListener {
                if (selectedPosition != position) {
                    val previousSelected = selectedPosition
                    selectedPosition = position
                    notifyItemChanged(previousSelected)
                    notifyItemChanged(selectedPosition)

                    onCategoryClick(category.name)
                }
            }
        }
    }
}