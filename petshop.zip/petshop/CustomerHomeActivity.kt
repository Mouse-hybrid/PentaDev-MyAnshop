package com.example.petshop

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import de.hdodenhof.circleimageview.CircleImageView

class CustomerHomeActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    
    // UI Components
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView
    private lateinit var productRecyclerView: RecyclerView
    private lateinit var categoryRecyclerView: RecyclerView
    private lateinit var searchView: SearchView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyView: LinearLayout

    // Adapters and Data
    private lateinit var productAdapter: ProductAdapter
    private val productList = mutableListOf<Product>()
    private val originalProductList = mutableListOf<Product>() 
    private lateinit var categoryAdapter: CustomerCategoryAdapter
    private val categoryList = mutableListOf<Category>()
    private var selectedCategory: String = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer_home)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        initViews()
        setupDrawerAndToolbar()
        updateNavHeader()
        setupRecyclerViews()
        setupSearchView()

        fetchCategories()
        fetchProducts(selectedCategory)
    }

    private fun initViews() {
        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        searchView = findViewById(R.id.search_view)
        productRecyclerView = findViewById(R.id.recyclerViewProducts)
        categoryRecyclerView = findViewById(R.id.recycler_view_categories_filter)
        progressBar = findViewById(R.id.progress_bar)
        emptyView = findViewById(R.id.empty_view)
    }

    private fun setupDrawerAndToolbar() {
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "MyAn Shop"

        navView.setNavigationItemSelectedListener(this)

        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
    }

    private fun updateNavHeader() {
        val headerView: View = navView.getHeaderView(0)
        val navUsername: TextView = headerView.findViewById(R.id.nav_header_name)
        val navEmail: TextView = headerView.findViewById(R.id.nav_header_email)
        
        val user = auth.currentUser
        if (user != null) {
            navEmail.text = user.email
            db.collection("users").document(user.uid).get().addOnSuccessListener {
                if(it != null && it.exists()){ navUsername.text = it.getString("name") ?: "User" }
            }
        } else {
            navUsername.text = "MyAn Shop"
            navEmail.text = "contact@myanshop.com"
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> { /* Already on home */ }
            R.id.nav_cart -> startActivity(Intent(this, CartActivity::class.java))
            R.id.nav_orders -> startActivity(Intent(this, OrderHistoryActivity::class.java))
            R.id.nav_profile -> startActivity(Intent(this, ProfileActivity::class.java))
            R.id.nav_logout -> {
                auth.signOut()
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun setupRecyclerViews() {
        productAdapter = ProductAdapter(productList, false)
        productRecyclerView.layoutManager = GridLayoutManager(this, 2)
        productRecyclerView.adapter = productAdapter

        categoryRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
    }

    private fun setupSearchView() {
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = true
            override fun onQueryTextChange(newText: String?): Boolean {
                filterProducts(newText)
                return true
            }
        })
    }

    private fun fetchCategories() {
        db.collection("categories").orderBy("name").get()
            .addOnSuccessListener {
                categoryList.clear()
                categoryList.add(Category(id = "all", name = "All"))
                it.documents.mapNotNullTo(categoryList) { doc -> doc.toObject(Category::class.java) }
                categoryAdapter = CustomerCategoryAdapter(categoryList) { categoryName ->
                    selectedCategory = categoryName
                    fetchProducts(selectedCategory)
                }
                categoryRecyclerView.adapter = categoryAdapter
            }
    }

    private fun fetchProducts(categoryName: String) {
        showLoading(true)
        var query: Query = db.collection("products")
        if (categoryName != "All") {
            query = query.whereEqualTo("category", categoryName)
        }

        query.addSnapshotListener { snapshots, e ->
            showLoading(false)
            if (e != null) {
                Log.w("CustomerHome", "Listen failed.", e)
                return@addSnapshotListener
            }

            originalProductList.clear()
            snapshots?.mapNotNullTo(originalProductList) { doc -> doc.toObject(Product::class.java)?.copy(id = doc.id) }
            filterProducts(searchView.query.toString())
        }
    }

    private fun filterProducts(query: String?) {
        productList.clear()
        if (query.isNullOrEmpty()) {
            productList.addAll(originalProductList)
        } else {
            val filteredList = originalProductList.filter { it.name.contains(query, ignoreCase = true) }
            productList.addAll(filteredList)
        }
        productAdapter.notifyDataSetChanged()
        checkEmptyState()
    }
    
    private fun showLoading(isLoading: Boolean) {
        progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        productRecyclerView.visibility = if (isLoading) View.GONE else View.VISIBLE
    }
    
    private fun checkEmptyState(){
        emptyView.visibility = if (productList.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}