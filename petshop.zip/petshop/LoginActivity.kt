package com.example.petshop

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val email = findViewById<TextInputEditText>(R.id.edtEmail)
        val password = findViewById<TextInputEditText>(R.id.edtPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvRegister = findViewById<TextView>(R.id.tvRegister)

        btnLogin.setOnClickListener {
            val emailText = email.text.toString().trim()
            val passText = password.text.toString().trim()

            if (emailText.isEmpty() || passText.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.signInWithEmailAndPassword(emailText, passText)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        checkUserRole(auth.currentUser!!.uid)
                    } else {
                        Toast.makeText(this, "Authentication failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }

        tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun checkUserRole(uid: String) {
        db.collection("users").document(uid).get(Source.SERVER).addOnSuccessListener { document ->
            if (document != null && document.exists()) {
                val role = document.getString("role")
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()

                if (role == "admin") {
                    navigateTo(AdminHomeActivity::class.java)
                } else {
                    navigateTo(CustomerHomeActivity::class.java)
                }
            } else {
                 val user = auth.currentUser!!
                 val userProfile = User(
                        uid = user.uid,
                        name = user.displayName ?: "",
                        email = user.email ?: "",
                        role = "customer"
                    )
                 db.collection("users").document(user.uid).set(userProfile).addOnSuccessListener{
                    navigateTo(CustomerHomeActivity::class.java)
                 }
            }
        }.addOnFailureListener { exception ->
            Toast.makeText(this, "Failed to get user role: ${exception.message}", Toast.LENGTH_LONG).show()
            auth.signOut()
        }
    }

    private fun navigateTo(activityClass: Class<*>) {
        val intent = Intent(this, activityClass)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }
}