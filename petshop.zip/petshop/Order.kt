package com.example.petshop

import android.os.Parcelable
import com.google.firebase.firestore.ServerTimestamp
import kotlinx.parcelize.Parcelize
import java.util.Date

@Parcelize
data class Order(
    val orderId: String = "",
    val userId: String = "",
    val items: List<CartItem> = listOf(),
    val totalPrice: Double = 0.0,
    val status: String = "Pending",
    @ServerTimestamp val createdAt: Date? = null,
    val customerName: String = "",
    val address: String = "", 
    val phone: String = ""
) : Parcelable