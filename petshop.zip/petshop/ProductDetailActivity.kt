package com.example.petshop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val productNameView: TextView = findViewById(R.id.tv_product_name_detail)
        val productPriceView: TextView = findViewById(R.id.tv_product_price_detail)
        val productDescriptionView: TextView = findViewById(R.id.tv_product_description_detail)
        val productImageView: ImageView = findViewById(R.id.img_product_detail)
        val addToCartButton: Button = findViewById(R.id.btn_add_to_cart)

        val productId = intent.getStringExtra("PRODUCT_ID")
        val productName = intent.getStringExtra("PRODUCT_NAME")
        val productPrice = intent.getDoubleExtra("PRODUCT_PRICE", 0.0)
        val productImageUrl = intent.getStringExtra("PRODUCT_IMAGE_URL")
        val productDescription = intent.getStringExtra("PRODUCT_DESCRIPTION")
        
        productNameView.text = productName
        productPriceView.text = "$${String.format("%.2f", productPrice)}"
        productDescriptionView.text = productDescription

        if (!productImageUrl.isNullOrEmpty()) {
            Glide.with(this).load(productImageUrl).centerCrop().placeholder(R.drawable.ic_launcher_background).into(productImageView)
        } else {
            productImageView.setImageResource(R.drawable.ic_launcher_background)
        }

        addToCartButton.setOnClickListener {
            if (productId != null) {
                addProductToCart(productId, productName, productPrice, productImageUrl)
            } else {
                Toast.makeText(this, "Error: Product ID is missing.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun addProductToCart(productId: String, name: String?, price: Double, imageUrl: String?) {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Please login to add items to cart", Toast.LENGTH_SHORT).show()
            return
        }

        val uid = currentUser.uid
        val cartItemRef = db.collection("carts").document(uid).collection("items").document(productId)

        db.runTransaction { transaction ->
            val snapshot = transaction.get(cartItemRef)
            if (snapshot.exists()) {
                val newQuantity = snapshot.getLong("quantity")!! + 1
                transaction.update(cartItemRef, "quantity", newQuantity)
            } else {
                // Create a new cart item WITHOUT the productId field
                val cartItem = hashMapOf(
                    "name" to name,
                    "price" to price,
                    "imageUrl" to (imageUrl ?: ""),
                    "quantity" to 1
                )
                transaction.set(cartItemRef, cartItem)
            }
            null
        }.addOnSuccessListener {
            Toast.makeText(this, "Added to cart", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener { e ->
            Toast.makeText(this, "Failed to add to cart: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}