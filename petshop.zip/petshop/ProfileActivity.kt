package com.example.petshop

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import de.hdodenhof.circleimageview.CircleImageView
import java.util.UUID

class ProfileActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var storage: FirebaseStorage

    private lateinit var avatarImage: CircleImageView
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var edtUserPhone: TextInputEditText
    private lateinit var edtUserAddress: TextInputEditText
    private lateinit var btnEditSave: Button

    private var imageUri: Uri? = null
    private var isEditMode = false

    companion object {
        private const val PICK_IMAGE_REQUEST = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        storage = FirebaseStorage.getInstance()

        avatarImage = findViewById(R.id.img_avatar)
        tvUserName = findViewById(R.id.tv_user_name)
        tvUserEmail = findViewById(R.id.tv_user_email)
        edtUserPhone = findViewById(R.id.edt_user_phone)
        edtUserAddress = findViewById(R.id.edt_user_address)
        btnEditSave = findViewById(R.id.btn_edit_save_profile)
        val btnLogout: Button = findViewById(R.id.btn_logout)

        loadUserProfile()

        avatarImage.setOnClickListener {
            if (isEditMode) {
                openFileChooser()
            }
        }

        btnEditSave.setOnClickListener {
            toggleEditMode()
        }

        btnLogout.setOnClickListener {
            auth.signOut()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }

    private fun toggleEditMode() {
        isEditMode = !isEditMode
        if (isEditMode) {
            edtUserPhone.isEnabled = true
            edtUserAddress.isEnabled = true
            btnEditSave.text = "Save Changes"
            Toast.makeText(this, "You can now edit your profile and tap the avatar to change it.", Toast.LENGTH_LONG).show()
        } else {
            updateUserProfile()
        }
    }

    private fun loadUserProfile() {
        val userId = auth.currentUser?.uid ?: return

        db.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val user = document.toObject(User::class.java)
                    user?.let {
                        tvUserName.text = it.name
                        tvUserEmail.text = it.email
                        edtUserPhone.setText(it.phone)
                        edtUserAddress.setText(it.address)
                        if (it.imageUrl.isNotEmpty()) {
                            Glide.with(this).load(it.imageUrl).into(avatarImage)
                        }
                    }
                }
            }
    }

    private fun updateUserProfile() {
        if (imageUri != null) {
            uploadImageAndUpdateData()
        } else {
            updateDataOnly("")
        }
    }

    private fun uploadImageAndUpdateData() {
        val fileName = UUID.randomUUID().toString()
        val storageRef = storage.reference.child("avatars/$fileName")

        storageRef.putFile(imageUri!!)
            .addOnSuccessListener { 
                storageRef.downloadUrl.addOnSuccessListener { uri ->
                    updateDataOnly(uri.toString())
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Image upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
                // Still try to update other data
                updateDataOnly("")
            }
    }

    private fun updateDataOnly(newImageUrl: String?) {
        val userId = auth.currentUser?.uid ?: return
        val phone = edtUserPhone.text.toString().trim()
        val address = edtUserAddress.text.toString().trim()

        val userUpdates = mutableMapOf<String, Any>(
            "phone" to phone,
            "address" to address
        )
        
        if(newImageUrl != null && newImageUrl.isNotEmpty()){
            userUpdates["imageUrl"] = newImageUrl
        }

        db.collection("users").document(userId).update(userUpdates)
            .addOnSuccessListener {
                Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                edtUserPhone.isEnabled = false
                edtUserAddress.isEnabled = false
                btnEditSave.text = "Edit Profile"
                imageUri = null // Reset image URI after upload
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to update profile: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun openFileChooser() {
        val intent = Intent().apply {
            type = "image/*"
            action = Intent.ACTION_GET_CONTENT
        }
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            imageUri = data.data
            avatarImage.setImageURI(imageUri)
        }
    }
}