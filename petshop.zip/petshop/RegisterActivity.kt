package com.example.petshop

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val email = findViewById<TextInputEditText>(R.id.edtEmail)
        val pass = findViewById<TextInputEditText>(R.id.edtPassword)
        val confirm = findViewById<TextInputEditText>(R.id.edtConfirm)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val tvLogin = findViewById<TextView>(R.id.tvLogin)

        btnRegister.setOnClickListener {
            val emailText = email.text.toString().trim()
            val passText = pass.text.toString().trim()
            val confText = confirm.text.toString().trim()

            if (emailText.isEmpty() || passText.isEmpty() || confText.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (passText != confText) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.createUserWithEmailAndPassword(emailText, passText)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Đăng ký thành công, lưu vai trò người dùng vào Firestore
                        val firebaseUser = auth.currentUser
                        val userMap = hashMapOf(
                            "role" to "customer" // Mặc định tất cả người dùng mới là customer
                        )

                        firebaseUser?.let {
                            db.collection("users").document(it.uid)
                                .set(userMap)
                                .addOnSuccessListener { 
                                    Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()
                                    finish() // Quay lại màn hình Login
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(this, "Failed to save user role: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                        }
                    } else {
                        // Đăng ký thất bại
                        Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }

        tvLogin.setOnClickListener {
            finish() // Quay lại màn hình Login
        }
    }
}